import 'package:flutter/material.dart';

class Event {
  final String Title;
  final String Description;
  final String Time;
  final DateTime Date;
  final String Zoomlink;


  Event({@required this.Title, @required this.Description, @required this.Time, @required this.Date,
    this.Zoomlink} );
}


