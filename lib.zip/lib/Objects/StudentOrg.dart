import 'package:flutter/material.dart';

class StudentOrg {
  final String Name;
  final String Description;
  final String Image;
  final String Chat;
  final String Website;
  final String Email;
  final String Instagram;
  final String Facebook;
  final String Page_Route;


  StudentOrg({@required this.Name, @required this.Description, @required this.Image, this.Chat,
    this.Website, this.Email, this.Instagram, this.Facebook, @required this.Page_Route} );
}
