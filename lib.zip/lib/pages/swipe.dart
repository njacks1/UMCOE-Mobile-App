import 'package:coe_mobile_app/Animation/FadeAnimation.dart';
import 'package:coe_mobile_app/Objects/studentorg.dart';
import 'package:coe_mobile_app/constants/color_constant.dart';
import 'package:coe_mobile_app/pages/studentorg_swipe.dart';
//import 'package:coe_app/pages/studentorg_swipe.dart';
import 'package:flutter/material.dart';
import 'tutoring_swipe.dart';
import 'events_swipe.dart';
import 'events_swipe1.dart';
import 'package:jiffy/jiffy.dart';


// 1/10 Sized Box to cover AppBar
// 1/20 Hello
// 1/15 Scrollbar
// 1/60 Sized Box
// 23/30 container

void main() => runApp(MyApp());

bool diff_in_days(DateTime dateofevent ) {
  final weekofevent = Jiffy(dateofevent).week;
  final datenow = DateTime.now();
  final weeknow = Jiffy(datenow).week;
  if (weekofevent == weeknow ) {
    print("same week");
    return true;}
  else{
    print("different week");
    return false;}
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage>
    with SingleTickerProviderStateMixin {
  TabController _tabController;
  TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    //Screen Size
    double ScreenHeight = MediaQuery.of(context).size.height;
    double ScreenWidth = MediaQuery.of(context).size.width;
    double leftalign = ScreenWidth * 1/25;
    var x = diff_in_days(DateTime(2020, 10, 31));
    print(x);


    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.menu, color: kMain_IconColor),
          onPressed: () {},
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.mail, color: kMain_IconColor),
            onPressed: () {},
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [
          kBackGradient1,
          kBackGradient2,
          kBackGradient3,
                  kBackGradient4,
        ])),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(height: ScreenHeight * 1/10),
            Container(
                height: ScreenHeight * 1/20,
                margin: EdgeInsets.only(left: leftalign),
                child: FittedBox(
                  child: Text("Hello $kStudentName",
                      style: TextStyle(
                        fontFamily: 'AvenirNext',
                        fontWeight: FontWeight.w900,
                        letterSpacing: .40,
                        color: kMain_HeadingTextColor,
                      )),
                )),
            //SizedBox(height: ScreenHeight * 1/20),
//            TextField(
//              maxLines: 2,
//              onChanged: (string) {},
//              //controller: _controller,
//              decoration: InputDecoration(
//                  labelText: "Search",
//                  hintText: "Search",
//                  prefixIcon: Icon(Icons.search),
//                  border: OutlineInputBorder(
//                      borderRadius: BorderRadius.all(Radius.circular(25.0)))),
//            ),

            Container(
              height: ScreenHeight * 1/15,
              child: TabBar(
                  controller: _tabController,
                  indicatorColor: Colors.transparent,
                  labelColor: kMain_ScrollTextColorOnPress,
                  isScrollable: true,
                  labelPadding: EdgeInsets.only(left: leftalign, right: leftalign),
                  unselectedLabelColor: kMain_ScrollTextColor,
                  tabs: [
                    Tab(
                      child: Container(
                        height: ScreenHeight * 1/30,
                        child: FittedBox(
                          child: Text('Events',
                              style: TextStyle(
                                fontFamily: 'AvenirNext',
                                fontWeight: FontWeight.w700,
                              )),
                        ),
                      ),
                    ),
                    Tab(
                      child: Container(
                        height: ScreenHeight * 1/30,
                        child: FittedBox(
                          child: Text('Tutoring',
                              style: TextStyle(
                                fontFamily: 'AvenirNext',
                                fontWeight: FontWeight.w700,
                              )),
                        ),
                      ),
                    ),
                    Tab(
                      child: Container(
                        height: ScreenHeight * 1/30,
                        child: FittedBox(
                          child: Text('Student Orgs',
                              style: TextStyle(
                                fontFamily: 'AvenirNext',
                                fontWeight: FontWeight.w700,
                              )),
                        ),
                      ),
                    )
                  ]),
            ),
            SizedBox( height: ScreenHeight * 1/60),
            ClipRRect(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(50), topRight: Radius.circular(50)),
              child: Container(
                  height: ScreenHeight * 23/30,
                  width: double.infinity,
                  child: TabBarView(controller: _tabController, children: [
                    Events1Swipe(),
                    TutoringSwipe(),
                    StudentOrgSwipe()
                  ])),
            )
          ],
        ),
      ),
    );
  }
}

