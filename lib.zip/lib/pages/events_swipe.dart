import 'package:coe_mobile_app/DataMap/Event_DataMap.dart';
import 'package:coe_mobile_app/Objects/Event.dart';
import 'package:coe_mobile_app/componets/zoom_button.dart';
import 'package:coe_mobile_app/constants/color_constant.dart';
import 'package:flutter/material.dart';
import 'dart:io' as a;
import 'package:jiffy/jiffy.dart';
import 'package:intl/intl.dart';

bool diff_in_days(DateTime dateofevent) {

  final weekofevent = Jiffy(dateofevent).week;
  final datenow = DateTime.now();
  final weeknow = Jiffy(datenow).week;
  if (weekofevent == weeknow) {
    print("same week");
    return true;
  } else {
    print("different week");
    return false;
  }
}

class EventsSwipe extends StatelessWidget {

  List<Card> buildChildrenList(BuildContext context) {
    List<Card> _ThisWeekEvents = [];
    List<Card> _UpcomingEvents = [];

    for (Event X in EventDataMap.dataMap.values) {
      Card E = Card(
        child: ExpansionTile(
            title: Container(
              child: Text(X.Title,
                  style: TextStyle(
                      fontFamily: "AvenirNext",
                      fontWeight: FontWeight.w700,
                      fontSize: 24)),
            ),
            subtitle: Text(X.Description,
                style: TextStyle(
                    fontFamily: "AvenirNext",
                    fontWeight: FontWeight.w300,
                    fontSize: 18)),
            //String date = DateFormat("yyyy-MM-dd hh:mm:ss").format(DateTime.now());
//                          trailing: Text( '$DateFormat.yMd().format(EventDataMap.dataMap[key].Date)',
//                              style: TextStyle(
//                                  fontFamily: "AvenirNext",
//                                  fontWeight: FontWeight.w700,
//                                  fontSize: 16)),
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    //crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Time: ",
                          style: TextStyle(
                              fontFamily: "AvenirNext",
                              fontWeight: FontWeight.w500,
                              fontSize: 24,
                              color: kEvent_BodyTextColor)),
                      Text(X.Time,
                          style: TextStyle(
                              fontFamily: "AvenirNext",
                              fontWeight: FontWeight.w500,
                              fontSize: 24,
                              color: kEvent_TimeTextColor)),
                    ],
                  ),
                  zoom_button(
                      hyperlink: X.Zoomlink),
                  Padding(padding: EdgeInsets.all(10.0)),
                ],
              ),
            ]),
      );

      var isweek = diff_in_days(X.Date);
      if (isweek == true)
        _ThisWeekEvents.add(E);
      else
        _UpcomingEvents.add(E);
    }
  }





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              //onChanged: onItemChanged,
              //controller: _textController,
              decoration: InputDecoration(
                  labelText: "Search",
                  hintText: "Search",
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(25.0)))),
            ),
          ),
          SingleChildScrollView(
            child: Column(
              children: [
                Text("This Week",
                    style: TextStyle(
                        fontFamily: "AvenirNext",
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        color: kEvent_HeadingTextColor)),

                //NeverScrollableScrollPhysics()

              ],
            ),
          ),
        ],
      ), //
    );
  }
}
