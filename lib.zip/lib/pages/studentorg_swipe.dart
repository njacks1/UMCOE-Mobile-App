import 'package:coe_mobile_app/DataMap/StudentOrg_DataMap.dart';
import 'package:coe_mobile_app/Objects/StudentOrg.dart';
import 'package:coe_mobile_app/pages/studentorg_page.dart';
import 'package:flutter/material.dart';
import 'dart:io' as a;




class StudentOrgSwipe extends StatefulWidget {
  @override
  _StudentOrgSwipeState createState() => new _StudentOrgSwipeState();
}

class _StudentOrgSwipeState extends State<StudentOrgSwipe> {
  List<StudentOrg> _StudentOrgs = List();
  List<StudentOrg> _FilteredStudentOrgs = List();
  TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
    setState(() {
      for (String org in StudentOrg_DataMap.dataMap.keys) {
        StudentOrg S = StudentOrg_DataMap.dataMap[org];
        _StudentOrgs.add(S);
      }
      _FilteredStudentOrgs = _StudentOrgs;
    });
  }

  @override
  void dispose() {
    // Clean up the controller when the widget is removed from the
    // widget tree.
    _controller.dispose();
    super.dispose();
  }

//  Future<List> buildChildrenList(BuildContext context) async {
//    List<StudentOrg> _StudentOrgs = [];
//    List<StudentOrg> _StudentOrgsForDisplay =[];
//
//    for (String org in StudentOrg_DataMap.dataMap.keys) {
//      StudentOrg S = StudentOrg_DataMap.dataMap[org];
//      _StudentOrgs.add(S);
//    }
//    return _StudentOrgs;
//  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ClipRRect(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(60), topRight: Radius.circular(60)),
        child: Container(
          decoration: BoxDecoration(color: Colors.white),
          margin: EdgeInsets.fromLTRB(0, 30.0, 0, 0),
          child: Column(
            children: <Widget> [
              Padding(
                padding: EdgeInsets.all(8.0),
                child: TextField(
                  keyboardType: TextInputType.text,
                  //controller: _controller,
                  decoration: InputDecoration(
                      labelText: "Search",
                      hintText: "Search",
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(
                          borderRadius:
                              BorderRadius.all(Radius.circular(25.0)))),
                  onChanged: (string) {
                    setState(() {
                      _FilteredStudentOrgs = _StudentOrgs.where((u) =>
                      (u.Name.toLowerCase()
                          .contains(string.toLowerCase()))).toList();
                    });
                  },

                ),
              ),
              Expanded(
                child: ListView.builder(
                    itemCount: _FilteredStudentOrgs.length,
                    itemBuilder: (BuildContext context, int index) {
                      //String key = StudentOrg_DataMap.dataMap.keys.elementAt(index);
                      return ListTile(
                        contentPadding: EdgeInsets.fromLTRB(20.0, 0, 0, 0),
                        leading: CircleAvatar(
                          backgroundImage: FileImage(
                              a.File(_FilteredStudentOrgs[index].Image)),
                        ),
                        title: new Text(_FilteredStudentOrgs[index].Name,
                            style: TextStyle(
                                fontFamily: "AvenirNext",
                                fontWeight: FontWeight.w700,
                                fontSize: 18)),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => StudentOrgPage(
                                  Org: _FilteredStudentOrgs[index]),
                            ),
                          );
                        },
                      );
                    }
                    //children: buildChildrenList(context)
                    ),
              ),
            ],
          ),
        ),
      ), //
    );
  }
}
