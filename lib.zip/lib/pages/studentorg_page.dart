import 'package:coe_mobile_app/Objects/StudentOrg.dart';
import 'package:coe_mobile_app/constants/color_constant.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

// 1/10 Sized Box to cover AppBar
// 1/20 Hello
// 1/15 Scrollbar
// 1/60 Sized Box
// 23/30 container

class StudentOrgPage extends StatelessWidget {
  final StudentOrg Org;

  StudentOrgPage({Key key, @required this.Org}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double ScreenHeight = MediaQuery
        .of(context)
        .size
        .height;
    double ScreenWidth = MediaQuery
        .of(context)
        .size
        .width;
    double leftalign = ScreenWidth * 1 / 25;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        centerTitle: true,
        actions: <Widget>[],
      ),
      body: Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  kBackGradient1,
                  kBackGradient2,
                  kBackGradient3,
                  kBackGradient4,
                ])),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(height: ScreenHeight * 7 / 30),
            Stack(
              children: <Widget>[
                ClipRRect(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(50),
                      topRight: Radius.circular(50)),
                  child: Container(
                    height: ScreenHeight * 23 / 30,
                    color: kOrg_Background,
                    padding: EdgeInsets.only(top: 70.0, left: leftalign),
                    child: SingleChildScrollView(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.only(
                                  bottom: 20.0, right: leftalign),
                              child: Text(Org.Name,
                                  style: TextStyle(
                                      fontFamily: "AvenirNext",
                                      fontWeight: FontWeight.w700,
                                      fontSize: 24)),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  bottom: 20.0, right: leftalign),
                              child: Text(Org.Description,
                                  style: TextStyle(
                                      fontFamily: "AvenirNext",
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18)),
                            ),
                            if (Org.Chat != null)
                              Padding(
                                padding:
                                EdgeInsets.fromLTRB(0, 15.0, 10.0, 15.0),
                                child: SizedBox(
                                  width: 150,
                                  child: RaisedButton(
                                      color: kOrg_ChatButtonColor,
                                      child: Text("Join Chat",
                                          style: TextStyle(
                                              fontFamily: "AvenirNext",
                                              fontWeight: FontWeight.w800,
                                              fontSize: 22,
                                              color: kOrg_ButtonTextColor)),
                                      onPressed: () async {
                                        if (await canLaunch(Org.Chat)) {
                                          await launch(Org.Chat);
                                        }
                                      },
                                      padding: EdgeInsets.all(15.0),
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(12.0)))),
                                ),
                              ),
                            Row(
                              children: [
                                if (Org.Website != null)
                                  Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        0, 15.0, 30.0, 30.0),
                                    child: SizedBox(
                                      width: 150,
                                      child: RaisedButton(
                                          color: kOrg_WebsiteButtonColor,
                                          child: Text("Website",
                                              style: TextStyle(
                                                  fontFamily: "AvenirNext",
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: 22,
                                                  color: kOrg_ButtonTextColor)),
                                          onPressed: () async {
                                            if (await canLaunch(Org.Website)) {
                                              await launch(Org.Website);
                                            }
                                          },
                                          padding: EdgeInsets.all(15.0),
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(12.0)))),
                                    ),
                                  ),
                                if (Org.Email != null)
                                  Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        0, 15.0, 30.0, 30.0),
                                    child: SizedBox(
                                      width: 150,
                                      child: RaisedButton(
                                          color: kOrg_EmailButtonColor,
                                          child: Text("Email",
                                              style: TextStyle(
                                                  fontFamily: "AvenirNext",
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: 22,
                                                  color: kOrg_ButtonTextColor)),
                                          onPressed: () => {},
                                          padding: EdgeInsets.all(15.0),
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(12.0)))),
                                    ),
                                  ),
                              ],
                            ),
                            Row(
                              children: [
                                if (Org.Facebook != null)
                                  IconButton(
                                    icon: Image.asset(
                                        'images/socialmedia_icons/facebook_logo.png'),
                                    iconSize: 50,
                                    onPressed: () async {
                                      if (await canLaunch(Org.Facebook)) {
                                        await launch(Org.Facebook);
                                      }
                                    },
                                  ),
                                if (Org.Instagram != null)
                                  IconButton(
                                    icon: Image.asset(
                                        'images/socialmedia_icons/instagram_logo.png'),
                                    iconSize: 50,
                                    onPressed: () async {
                                      if (await canLaunch(Org.Instagram)) {
                                        await launch(Org.Instagram);
                                      }
                                    },
                                  ),
                              ],
                            )
                          ]),
                    ),
                  ),
                ),
                Positioned(
                  top: -100,
                  left: 100,
                  child: Container(
                    padding: EdgeInsets.all(15.0),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(25.0)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          )
                        ]),
                    width: 200.0,
                    height: 150.0,
                    child: FittedBox(
                      child: Image.asset(Org.Image),
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                )
              ],
              overflow: Overflow.visible,
            )
          ],
        ),
      ),
    );
  }
}
