import 'package:coe_mobile_app/DataMap/Tutoring_DataMap.dart';
import 'package:coe_mobile_app/constants/color_constant.dart';
import 'package:coe_mobile_app/componets/tutor_icon.dart';
import 'package:flutter/material.dart';


class TutoringSwipe extends StatelessWidget {

  List<Widget> buildChildrenList(BuildContext context) {
    List<tutor_icon> displayList = [];

    for (String category in Tutoring_DataMap.dataMap.keys) {
      tutor_icon T = tutor_icon(
        TR: Tutoring_DataMap.dataMap[category],
        acronym: category,
      );
      displayList.add(T);
    }
    return displayList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: ClipRRect(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(60),
              topRight: Radius.circular(60)),
          child: Container(
            decoration: BoxDecoration(
                color: Colors.white),
            child: GridView.count(
              // Create a grid with 2 columns. If you change the scrollDirection to
              // horizontal, this produces 2 rows.
                crossAxisCount: 2,
                // Generate 100 widgets that display their index in the List.
                children: buildChildrenList(context)
            ),
          ),
        ), //
                );
  }
}




