import 'package:coe_mobile_app/Objects/TutoringResource.dart';
import 'package:flutter/material.dart';
import 'package:coe_mobile_app/CustomIcons.dart';
import 'package:firebase_core/firebase_core.dart';
//import 'package:firebase_analytics/firebase_analytics.dart';
//import 'package:firebase_analytics/observer.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

//This is the main area where we parameterize the data for the Tutoring Pages
//This follows the hierarchy and uses a map.

class Tutoring_DataMap{
  static final Map<String, TutoringResource> dataMap = {
    'SWE':
      TutoringResource(
        Name: "Society of Women Engineers",
        Description: "Society of Women Engineers hosts open zoom rooms each week with tutors for physics, calculus, intro to programming, intro to matlab, and other intro classes. ",
        gradient1:Color.fromRGBO(188, 72, 222, 91),
        gradient2: Color.fromRGBO(255, 95, 170, 99),
        Icon_data: CustomIcons.swe,
        RequestTutoring: 'https://docs.google.com/forms/d/e/1FAIpQLSd2ylYAwB3rED0WF93-JXeFnYGOCtzNzpac-8XsW4a6fInzEg/viewform',
        ViewSchedule: null,
        Zoomlink: null),

    'HKN':
      TutoringResource(
        Name: "Eta Kappa Nu Honor Society",
        Description: "Eta Kappa Nu members provide coverage for ECE classes through junior year level as well as intro PHY courses. They are hosting virtual office hour style over Zoom.",
        gradient1:Color.fromRGBO(19, 237, 124, 100),
        gradient2: Color.fromRGBO(14, 161, 172, 49),
        Icon_data: Icons.offline_bolt,
          RequestTutoring: null,
          ViewSchedule: null,
          Zoomlink: 'https://miami.zoom.us/j/91480791435?pwd=bHdOQjlhRzVoNExwUmNmdGNnbmoyUT09#success'),

    'ASCE':
      TutoringResource(
          Name: "American Society of Civil Engineers",
          Description: "American Society of Civil Engineers is  hosting tutoring sessions for civil and architectural course. ",
          gradient1: Color.fromRGBO(31, 1, 252, 100),
          gradient2: Color.fromRGBO(127, 185, 245, 100),
          Icon_data: Icons.content_cut,
          RequestTutoring: 'n/a',
          ViewSchedule: null,
          Zoomlink: null),

    'MATH':
      TutoringResource(
          Name: "Math Lab",
          Description: " ",
          gradient1: Color.fromRGBO(219, 4, 26, 91),
          gradient2: Color.fromRGBO(238, 53, 0, 53),
          Icon_data: CustomIcons.math,
          RequestTutoring: 'n/a',
          ViewSchedule: null,
          Zoomlink: null),

    'PHYSICS':
      TutoringResource(
          Name: "Physics Academy",
          Description: " ",
          gradient1: Color.fromRGBO(247, 174, 5, 69),
          gradient2: Color.fromRGBO(247, 174, 5, 69),
          Icon_data: CustomIcons.physics,
          RequestTutoring: 'n/a',
          ViewSchedule: null,
          Zoomlink: null),

    'CAMNER':
      TutoringResource(
          Name: "Camner Center",
          Description: " ",
          gradient1: Color.fromRGBO(253, 71, 46, 100),
          gradient2: Color.fromRGBO(247, 174, 5, 69),
          Icon_data: CustomIcons.miami_hurricanes_logo,
          RequestTutoring: 'n/a',
          ViewSchedule: null,
          Zoomlink: null),
  };
}
