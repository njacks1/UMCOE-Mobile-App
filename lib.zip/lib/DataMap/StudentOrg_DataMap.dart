import 'package:coe_mobile_app/Objects/StudentOrg.dart';
import 'package:firebase_core/firebase_core.dart';
//import 'package:firebase_analytics/firebase_analytics.dart';
//import 'package:firebase_analytics/observer.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

//This is the main area where we parameterize the data for the Student Org Page
//This follows the hierarchy and uses a map.

class StudentOrg_DataMap{
  static final Map<String, StudentOrg> dataMap = {
    'AIAA':
    StudentOrg(
        Name: "American Institute of Aeronautics & Astronautics",
        Description: "Assists students in advancing abilities through intense hands- on projects such as propulsion systems, software design, aerodynamic & structural analysis, and aviation systems.",
        Image: "images/AIAA_Logo.jpg",
        Page_Route: null,),

    'ASME':
    StudentOrg(
      Name: "American Society of Mechanical Engineers",
      Description: "n/a",
      Image:  "images/HKNlogo.png",
      Page_Route: null,),

    'BMES':
    StudentOrg(
      Name: "Biomedical Engineering Society",
      Description: "Introduces students to the profession of biomedical engineering, enhances and expands the knowledge of BMES members, and develops leadership and professional qualities.",
      Image:"images/Bmes_Logo.jpg",
      Website: 'https://miami.campuslabs.com/engage/organization/biomedical-engineering-society',
      Email: "dml192@miami.edu",
      Instagram: 'https://www.instagram.com/umiamibmes/',
      Facebook: 'https://www.facebook.com/umiamibmes/',
      Chat: 'https://web.groupme.com/join_group/52005370/3Lpzm2LC'),


    'ESC':
    StudentOrg(
      Name: "Engineering Student Council",
        Description: "Serves as the liason between students, clubs, societies, and administration within the College of Engineering. We increase engineering awareness, and provide for the professional advancement of all UM Engineering students.",
        Image:"images/ESC_Logo.png",
        Website: 'https://umiamiesc.wixsite.com/umiami',
        Email: 'mll156@miami.edu',
        Instagram: 'https://www.instagram.com/umiamiesc/',
        Facebook: null,
        Chat: null),

    'EWB':
    StudentOrg(
      Name: "Engineers without Borders",
      Description: "n/a",
      Image: "images/HKNlogo.png",
      Page_Route: null,),


    'HKN':
    StudentOrg(
      Name: "Eta Kappa Nu",
      Description: "n/a",
      Image: "images/HKNlogo.png",
      Page_Route: null,),


    'NSBE':
    StudentOrg(
      Name: "National Society of Black Engineers",
      Description: "n/a",
      Image: "images/HKNlogo.png",
      Page_Route: null,),


    'SASE':
    StudentOrg(
      Name: "Society of Asian Scientists and Engineers",
      Description: "n/a",
      Image: "/Users/maisylam/AndroidStudioProjects/coe_app/images/HKNlogo.png",
      Page_Route: null,),



  };
}
