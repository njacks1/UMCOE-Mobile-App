import 'package:coe_mobile_app/Objects/Event.dart';
import 'package:firebase_core/firebase_core.dart';
//import 'package:firebase_analytics/firebase_analytics.dart';
//import 'package:firebase_analytics/observer.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

//This is the main area where we parameterize the data for Events Page
//This follows the hierarchy and uses a map.

class EventDataMap{
  static final Map<int, Event> dataMap = {
    1:
    Event(
      Title: "Fall Involvement Fair",
      Description: "Hear from the Student Orgs and learn how to get involved!",
      Time: "8:00 PM EST",
      Date: DateTime(2020, 10, 31),
      Zoomlink: 'https://miami.zoom.us/j/9710256337'),

    2:
    Event(
      Title: "SWE Meeting",
      Description: "Join the Society of Women Engineers for their general body meeting!",
      Time:  "8:00 PM EST",
      Date:  DateTime(2020, 11, 12),
      Zoomlink: null,),

    3:
    Event(
      Title: "EPIC Career Interviews",
      Description: "Practice your interview skills with real companies! ",
      Time:"8:00 PM EST",
      Date: DateTime(2020, 11, 15),
      Zoomlink: null,),


    4:
    Event(
      Title: "NSBE Meeting",
      Description: "Join the Society of Black Engineers for their general body meeting!",
      Time: "8:00 PM EST",
      Date: DateTime(2020, 12, 15),
      Zoomlink: null,),

    5:
    Event(
      Title: "Graduate Student Panel",
      Description: "Hear tips regarding getting into graduate school froom our panel.",
      Time: "8:00 PM EST",
      Date: DateTime(2020, 12, 30),
      Zoomlink: null,),


  };
}
